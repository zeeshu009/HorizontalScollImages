let scrollEvt = document.querySelector(".gallery");
let bckBtn = document.getElementById("bckBtn");
let nxtBtn = document.getElementById("nxtBtn");

scrollEvt.addEventListener("wheel",(event)=>{
    event.defaultPrevented();
    scrollEvt.scrollLeft+=event.deltaY;
    scrollEvt.style.scrollBehavior = "auto";
});

bckBtn.addEventListener("click",()=>{
    scrollEvt.style.scrollBehavior = "smooth";  
    scrollEvt.scrollLeft-=900;
});

nxtBtn.addEventListener("click",()=>{
    scrollEvt.style.scrollBehavior = "smooth";  
    scrollEvt.scrollLeft+=900;
});
